const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://nestorcroww:nestor182@cluster0.7bwvo.mongodb.net/Chat?retryWrites=true&w=majority', {
    useNewUrlParser: true
})
  .then(db => console.log('db connected'))
  .catch(err => console.log(err));